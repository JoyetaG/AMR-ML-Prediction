#!/usr/bin/env python
"""
Single-file pipeline: AMR prediction in Staphylococcus aureus (Staph_AMR_only.xlsx).

Trains LSTM, CNN, MLP, Decision Tree, XGBoost, Logistic Regression and SGD on the real
isolate table (stratified 80/20 split, SMOTE on training data only), then writes Table 3-style
performance, XGBoost top-10 features (Table 2-style), a SHAP beeswarm plot and per-drug scores.

NOTE: this is a clean re-analysis on the real data. Its numbers differ from earlier manuscript drafts.

Usage:  python amr_pipeline_single_file.py --data Staph_AMR_only.xlsx --out results
        python amr_pipeline_single_file.py --data Staph_AMR_only.xlsx --out results_test --quick
"""
from __future__ import annotations

import argparse, json, platform, random
from dataclasses import dataclass, field
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, cohen_kappa_score,
                             confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import StratifiedKFold, cross_validate, train_test_split
from sklearn.multiclass import OneVsRestClassifier
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier


SEED = 42


@dataclass
class Config:
    data_path: str = "data/Staph_AMR_only.xlsx"
    out_dir: str = "results"
    # column names
    categorical: list = field(default_factory=lambda: [
        "allele", "most_common_allele", "ref_locus_tag", "eggnog_gene", "eggnog_annotation", "Name of the Drug Applied"])
    numeric: list = field(default_factory=list)
    target: str = "Is it AMR gene?"
    drug_col: str = "Name of the Drug Applied"
    # split / resampling
    test_size: float = 0.20          # stratified 80/20 split
    cv_folds: int = 5                # stratified 5-fold CV inside the training set
    smote_k: int = 5
    # deep-learning training
    seq_len: int = 50                # "sequence length was set to 50" (see README)
    epochs_lstm_cnn: int = 100
    epochs_mlp: int = 150
    batch_size: int = 32
    early_stop_patience: int = 10
    val_fraction: float = 0.10
    seed: int = SEED





def load(cfg: Config) -> pd.DataFrame:
    path = str(cfg.data_path)
    df = pd.read_excel(path) if path.lower().endswith((".xlsx", ".xls")) else pd.read_csv(path)
    needed = cfg.categorical + cfg.numeric + [cfg.target]
    missing = [c for c in needed if c not in df.columns]
    if missing:
        raise ValueError(f"Columns missing from {cfg.data_path}: {missing}")
    df = df[needed].copy()
    df[cfg.categorical] = df[cfg.categorical].fillna("missing").astype(str)
    t = df[cfg.target]
    if t.dtype == object or str(t.dtype).startswith("str"):
        t = t.astype(str).str.strip().str.lower().map({"yes": 1, "no": 0, "1": 1, "0": 0})
    if t.isna().any():
        raise ValueError(f"Target column '{cfg.target}' has values other than Yes/No/1/0")
    df[cfg.target] = t.astype(int)
    return df


def make_preprocessor(cfg: Config) -> ColumnTransformer:
    """One-hot encode categoricals (feature names become e.g. cat__allele_Cluster_1015_Allele_8)
    and standardise any numeric features. Fitted on training data only."""
    transformers = [("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cfg.categorical)]
    if cfg.numeric:
        transformers.append(("num", StandardScaler(), cfg.numeric))
    return ColumnTransformer(transformers)


def split(df: pd.DataFrame, cfg: Config):
    """Stratified 80/20 train/test split, done BEFORE any encoding or resampling."""
    X, y = df.drop(columns=[cfg.target]), df[cfg.target]
    return train_test_split(X, y, test_size=cfg.test_size, stratify=y, random_state=cfg.seed)


def fit_transform_smote(X_train, y_train, cfg: Config):
    """Fit the preprocessor on the training set, then apply SMOTE to the training set only."""
    pre = make_preprocessor(cfg)
    Xt = pre.fit_transform(X_train)
    sm = SMOTE(k_neighbors=cfg.smote_k, random_state=cfg.seed)
    Xb, yb = sm.fit_resample(Xt, y_train)
    return pre, np.asarray(Xt), np.asarray(Xb), np.asarray(yb)





# ---------------------------------------------------------------- sklearn / XGBoost
def decision_tree(cfg):
    return DecisionTreeClassifier(max_depth=10, criterion="gini", min_samples_split=2,
                                  min_samples_leaf=1, class_weight="balanced",
                                  splitter="best", random_state=cfg.seed)


def logistic_regression(cfg):
    base = LogisticRegression(C=1.0, solver="lbfgs", class_weight="balanced",
                              tol=1e-4, max_iter=1000, random_state=cfg.seed)
    return OneVsRestClassifier(base)          # one-vs-rest scheme; L2 is the default penalty


def sgd(cfg):
    return SGDClassifier(loss="modified_huber", alpha=1e-4,
                         learning_rate="adaptive", eta0=0.01, power_t=0.25,
                         early_stopping=True, validation_fraction=0.1, max_iter=1000,
                         class_weight="balanced", random_state=cfg.seed)


def xgboost(cfg, y_fit):
    """Class weight computed from the class distribution of the data used for fitting."""
    pos = max(int((y_fit == 1).sum()), 1)
    neg = int((y_fit == 0).sum())
    return XGBClassifier(n_estimators=100, max_depth=6, learning_rate=0.1,
                         subsample=0.8, colsample_bytree=0.8,
                         objective="binary:logistic", eval_metric="auc",
                         early_stopping_rounds=cfg.early_stop_patience,
                         scale_pos_weight=neg / pos, random_state=cfg.seed, n_jobs=-1)


# ---------------------------------------------------------------- Keras models
def _to_sequence(X, seq_len):
    """Reshape a (n, F) matrix to (n, seq_len, ceil(F/seq_len)) by zero-padding the features.
    Nothing is truncated. The column order is the arbitrary one-hot order (see README)."""
    n, f = X.shape
    width = int(np.ceil(f / seq_len))
    pad = seq_len * width - f
    Xp = np.pad(X, ((0, 0), (0, pad)))
    return Xp.reshape(n, seq_len, width).astype("float32")


def build_lstm(input_shape):
    from tensorflow import keras
    from tensorflow.keras import layers
    m = keras.Sequential([
        layers.Input(shape=input_shape),
        layers.Dense(128, activation="relu"),                     # 128-unit input layer
        layers.LSTM(64, return_sequences=True, dropout=0.2),
        layers.LSTM(32, dropout=0.2),
        layers.Dense(16, activation="relu"),
        layers.Dense(1, activation="sigmoid")])
    m.compile(optimizer=keras.optimizers.Adam(1e-3), loss="binary_crossentropy", metrics=["accuracy"])
    return m


def build_cnn(input_shape):
    from tensorflow import keras
    from tensorflow.keras import layers
    m = keras.Sequential([
        layers.Input(shape=input_shape),
        layers.Conv1D(64, 3, activation="relu"), layers.MaxPooling1D(2),
        layers.Conv1D(32, 3, activation="relu"),
        layers.Flatten(),
        layers.Dense(64, activation="relu"), layers.Dense(32, activation="relu"),
        layers.Dropout(0.3),
        layers.Dense(1, activation="sigmoid")])
    m.compile(optimizer=keras.optimizers.Adam(1e-3), loss="binary_crossentropy", metrics=["accuracy"])
    return m


def build_mlp(n_features):
    from tensorflow import keras
    from tensorflow.keras import layers, regularizers
    l2 = regularizers.l2(0.01)
    m = keras.Sequential([
        layers.Input(shape=(n_features,)),
        layers.Dense(256, activation="relu", kernel_regularizer=l2), layers.Dropout(0.3),
        layers.Dense(128, activation="relu", kernel_regularizer=l2), layers.Dropout(0.2),
        layers.Dense(64, activation="relu", kernel_regularizer=l2),
        layers.Dense(1, activation="sigmoid")])
    m.compile(optimizer=keras.optimizers.Adam(1e-3), loss="binary_crossentropy", metrics=["accuracy"])
    return m


class KerasBinary:
    """Small sklearn-style wrapper: fit / predict_proba / predict, with early stopping."""

    def __init__(self, kind, cfg: Config, epochs=None):
        self.kind, self.cfg = kind, cfg
        self.epochs = epochs or (cfg.epochs_mlp if kind == "mlp" else cfg.epochs_lstm_cnn)

    def _prep(self, X):
        return X.astype("float32") if self.kind == "mlp" else _to_sequence(X, self.cfg.seq_len)

    def fit(self, X, y):
        from tensorflow import keras
        keras.utils.set_random_seed(self.cfg.seed)
        Xp = self._prep(X)
        self.model = (build_mlp(X.shape[1]) if self.kind == "mlp" else
                      build_lstm(Xp.shape[1:]) if self.kind == "lstm" else build_cnn(Xp.shape[1:]))
        # stratified validation split drawn from the (shuffled) training data
        Xa, Xv, ya, yv = train_test_split(Xp, y, test_size=self.cfg.val_fraction,
                                          stratify=y, random_state=self.cfg.seed)
        es = keras.callbacks.EarlyStopping(monitor="val_loss", patience=self.cfg.early_stop_patience,
                                           restore_best_weights=True)
        self.history = self.model.fit(Xa, ya, validation_data=(Xv, yv), epochs=self.epochs,
                                      batch_size=self.cfg.batch_size, callbacks=[es], verbose=0)
        return self

    def predict_proba(self, X):
        p = self.model.predict(self._prep(X), verbose=0).ravel()
        return np.column_stack([1 - p, p])

    def predict(self, X):
        return (self.predict_proba(X)[:, 1] >= 0.5).astype(int)


def build_all(cfg: Config, y_fit, only=None, epochs=None):
    """Return {name: untrained model}. `only` restricts to a subset; `epochs` is for smoke tests."""
    models = {
        "LSTM": KerasBinary("lstm", cfg, epochs),
        "CNN": KerasBinary("cnn", cfg, epochs),
        "MLP": KerasBinary("mlp", cfg, epochs),
        "Decision Tree": decision_tree(cfg),
        "XGBoost": xgboost(cfg, y_fit),
        "Logistic Regression": logistic_regression(cfg),
        "SGD": sgd(cfg),
    }
    return {k: v for k, v in models.items() if not only or k in only}





def score_model(model, X_train, y_train, X_test, y_test) -> dict:
    """Training accuracy is computed on the SMOTE-balanced training set (as in Table 3);
    all test metrics use the untouched, imbalanced test set."""
    p_tr, p_te = model.predict(X_train), model.predict(X_test)
    proba = model.predict_proba(X_test)[:, 1]
    tn, fp, fn, tp = confusion_matrix(y_test, p_te, labels=[0, 1]).ravel()
    return {
        "Training Acc. (%)": round(100 * accuracy_score(y_train, p_tr), 2),
        "Test Acc. (%)": round(100 * accuracy_score(y_test, p_te), 2),
        "ROC AUC": round(roc_auc_score(y_test, proba), 4),
        "F1-score (weighted)": round(f1_score(y_test, p_te, average="weighted"), 4),
        "Precision (AMR+)": round(precision_score(y_test, p_te, zero_division=0), 4),
        "Recall/Sensitivity (AMR+)": round(recall_score(y_test, p_te, zero_division=0), 4),
        "Specificity": round(tn / (tn + fp), 4) if (tn + fp) else np.nan,
        "Balanced Acc.": round(balanced_accuracy_score(y_test, p_te), 4),
        "Cohen kappa": round(cohen_kappa_score(y_test, p_te), 4),
        "TN": int(tn), "FP": int(fp), "FN": int(fn), "TP": int(tp),
    }


def cross_validate_leak_free(model, X_train, y_train, cfg) -> dict:
    """5-fold stratified CV on the training set. Inside every fold the encoder/scaler is fitted on the
    fold's training portion and SMOTE is applied to that portion only (imblearn Pipeline)."""
    est = clone(model)
    if "early_stopping_rounds" in est.get_params():
        est.set_params(early_stopping_rounds=None)     # no eval_set inside CV
    pipe = ImbPipeline([("pre", make_preprocessor(cfg)),
                        ("smote", SMOTE(k_neighbors=cfg.smote_k, random_state=cfg.seed)),
                        ("clf", est)])
    cv = StratifiedKFold(cfg.cv_folds, shuffle=True, random_state=cfg.seed)
    res = cross_validate(pipe, X_train, y_train, cv=cv,
                         scoring={"accuracy": "accuracy", "f1_weighted": "f1_weighted", "roc_auc": "roc_auc"})
    return {f"CV {k[5:]} mean": round(float(np.mean(v)), 4) for k, v in res.items() if k.startswith("test_")} | \
           {f"CV {k[5:]} sd": round(float(np.std(v)), 4) for k, v in res.items() if k.startswith("test_")}


def top_features_xgb(model, feature_names, k=10) -> pd.DataFrame:
    imp = pd.Series(model.feature_importances_, index=feature_names).sort_values(ascending=False).head(k)
    out = pd.DataFrame({"Rank": range(1, len(imp) + 1), "Feature name": imp.index,
                        "Importance (raw)": imp.values,
                        "Importance (normalised over top-k)": imp.values / imp.values.sum()})
    return out.round(6)


def shap_beeswarm(model, X_test_dense, feature_names, path, max_display=10):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import shap
    sv = shap.TreeExplainer(model).shap_values(X_test_dense)
    plt.figure()
    shap.summary_plot(sv, X_test_dense, feature_names=feature_names, max_display=max_display, show=False)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    mean_abs = pd.Series(np.abs(sv).mean(axis=0), index=feature_names).sort_values(ascending=False)
    return mean_abs.head(max_display).rename("mean |SHAP|").reset_index().rename(columns={"index": "Feature name"})


def per_group_scores(df_test, y_true, y_pred, group_col) -> pd.DataFrame:
    rows = []
    for g, idx in df_test.groupby(group_col).groups.items():
        pos = df_test.index.get_indexer(idx)
        yt, yp = np.asarray(y_true)[pos], np.asarray(y_pred)[pos]
        rows.append({group_col: g, "n": len(pos), "Accuracy": accuracy_score(yt, yp),
                     "F1 (weighted)": f1_score(yt, yp, average="weighted")})
    return pd.DataFrame(rows).round(4)


#!/usr/bin/env python
"""Train and evaluate the seven models (Table 3), XGBoost SHAP (Figure 3, Table 2) and per-drug
scores (Figure 4).

Example:
    python scripts/run_pipeline.py --data data/saureus_amr_features.csv --out results
    python scripts/run_pipeline.py --data data/synthetic.csv --out results_smoke --quick
"""




def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=Config.data_path)
    ap.add_argument("--out", default=Config.out_dir)
    ap.add_argument("--target", default=Config.target)
    ap.add_argument("--drug-col", default=Config.drug_col)
    ap.add_argument("--models", nargs="*", help="subset, e.g. XGBoost 'Decision Tree'")
    ap.add_argument("--no-cv", action="store_true", help="skip 5-fold CV of the non-deep models")
    ap.add_argument("--quick", action="store_true", help="3 epochs for the Keras models (smoke test only)")
    a = ap.parse_args()

    cfg = Config(data_path=a.data, out_dir=a.out, target=a.target, drug_col=a.drug_col)
    out = Path(cfg.out_dir); out.mkdir(parents=True, exist_ok=True)
    np.random.seed(cfg.seed); random.seed(cfg.seed)

    df = load(cfg)
    X_tr_df, X_te_df, y_tr, y_te = split(df, cfg)
    pre, X_tr, X_bal, y_bal = fit_transform_smote(X_tr_df, y_tr, cfg)
    X_te = np.asarray(pre.transform(X_te_df))
    names = list(pre.get_feature_names_out())

    json.dump({"n_total": len(df), "n_pos": int(df[cfg.target].sum()),
               "train_n": len(y_tr), "train_pos": int(y_tr.sum()),
               "test_n": len(y_te), "test_pos": int(y_te.sum()),
               "train_after_smote": len(y_bal), "n_features_after_encoding": len(names)},
              open(out / "split_summary.json", "w"), indent=2)
    (out / "versions.txt").write_text(f"python {platform.python_version()}\n" + "\n".join(
        f"{m} {__import__(m).__version__}" for m in
        ["numpy", "pandas", "sklearn", "imblearn", "xgboost", "shap", "tensorflow"]))

    models = build_all(cfg, y_bal, only=a.models, epochs=3 if a.quick else None)
    rows, cv_rows, fitted = [], [], {}
    for name, model in models.items():
        print(f"== {name}")
        if name == "XGBoost":                      # early stopping needs a validation set
            Xa, Xv, ya, yv = train_test_split(X_bal, y_bal, test_size=cfg.val_fraction,
                                              stratify=y_bal, random_state=cfg.seed)
            model.fit(Xa, ya, eval_set=[(Xv, yv)], verbose=False)
        else:
            model.fit(X_bal, y_bal)
        fitted[name] = model
        rows.append({"Model": name, **score_model(model, X_bal, y_bal, X_te, y_te)})
        if not a.no_cv and name in {"Decision Tree", "XGBoost", "Logistic Regression", "SGD"}:
            cv_rows.append({"Model": name, **cross_validate_leak_free(model, X_tr_df, y_tr, cfg)})

    res = pd.DataFrame(rows)
    res.to_csv(out / "table3_model_performance.csv", index=False)
    if cv_rows:
        pd.DataFrame(cv_rows).to_csv(out / "cv_scores_non_deep_models.csv", index=False)
    print(res.to_string(index=False))

    if "XGBoost" in fitted:
        xgb = fitted["XGBoost"]
        top_features_xgb(xgb, names).to_csv(out / "table2_top10_features_xgboost.csv", index=False)
        shap_beeswarm(xgb, X_te, names, out / "figure3_shap_beeswarm.png").to_csv(
            out / "shap_mean_abs_top10.csv", index=False)
        pd_scores = per_group_scores(X_te_df.reset_index(drop=True), y_te.values,
                                       xgb.predict(X_te), cfg.drug_col)
        pd_scores.to_csv(out / "figure4_per_drug_xgboost.csv", index=False)
        ax = pd_scores.set_index(cfg.drug_col)[["Accuracy", "F1 (weighted)"]].plot.bar(figsize=(9, 4.5), width=0.8)
        ax.set_ylim(0, 1.05); ax.set_ylabel("Score"); ax.set_title("Accuracy and F1 Score for each Drug for XGBoost Model")
        plt.xticks(rotation=35, ha="right"); plt.tight_layout()
        plt.savefig(out / "figure4_per_drug_xgboost.png", dpi=300); plt.close()
    print(f"\nResults written to {out.resolve()}")


if __name__ == "__main__":
    main()
