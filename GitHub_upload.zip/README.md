# AMR prediction in *Staphylococcus aureus* – analysis code

Code accompanying: Ghosh J, Kant R, Taneja J. "Machine learning–driven prediction of antimicrobial
resistance in *Staphylococcus aureus* using genomic and allelic signatures." Front. Microbiol. (2026).
DOI: 10.3389/fmicb.2026.1877073

`amr_pipeline.py` trains and evaluates seven models (LSTM, CNN, MLP, Decision Tree, XGBoost,
Logistic Regression, SGD) on the isolate table `Staph_AMR_only.xlsx` (300 rows, six antibiotics):
one-hot encoding, stratified 80/20 split (random_state=42), SMOTE (k=5) on training data only,
5-fold cross-validation, SHAP for XGBoost, and per-drug evaluation.

## Run
    pip install -r requirements.txt
    python amr_pipeline.py --data Staph_AMR_only.xlsx --out results          # full run
    python amr_pipeline.py --data Staph_AMR_only.xlsx --out results --quick  # fast check

## Note
Only 22 of 300 rows are AMR-positive, so the held-out test set contains very few positives and
test metrics vary with the split, seed and software versions. Exact values from a re-run may differ
slightly from those reported in the paper. Package versions are written to `results/versions.txt`.
