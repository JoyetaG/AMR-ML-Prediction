# Data

This pipeline expects a single CSV at `data/amr_features.csv` (or a path
passed via `--data`) with one row per (isolate, drug) observation and the
following columns:

| column               | type   | description                                          |
|-----------------------|--------|-------------------------------------------------------|
| `isolate_id`          | str/int| unique identifier for the *S. aureus* isolate         |
| `allele`               | str    | allele identifier                                    |
| `most_common_allele`   | str    | most-common-allele call                              |
| `ref_locus_tag`        | str    | reference locus tag                                  |
| `eggnog_gene`          | str    | EggNOG gene label                                    |
| `eggnog_annotation`    | str    | EggNOG functional annotation                         |
| `drug`                 | str    | antibiotic name                                      |
| `label`                | int    | binary AMR label (1 = resistant, 0 = non-resistant)  |

The categorical columns (`allele`, `most_common_allele`, `ref_locus_tag`,
`eggnog_gene`, `eggnog_annotation`) are one-hot encoded inside the
pipeline (see `src/data_preprocessing.py`); do not one-hot encode them
yourself before loading.

This data file is intentionally **not** committed to the repository (see
`.gitignore`). Add your own dataset locally, or point `--data` at wherever
it lives.
