# Machine Learning–Driven Prediction of Antimicrobial Resistance in *Staphylococcus aureus*

Reproducible code accompanying the manuscript **"Machine Learning–Driven
Prediction of Antimicrobial Resistance in *Staphylococcus aureus* Using
Genomic and Allelic Signatures"** (Manuscript ID 1877073).

This repository trains and compares seven machine learning models — LSTM,
CNN, Multi-Layer Perceptron (MLP), Decision Tree, XGBoost, Logistic
Regression, and SGD — to predict antimicrobial resistance (AMR) from
allele-level genomic features (allele, most-common-allele, reference locus
tag, and EggNOG gene/annotation), across six antibiotics: Ciprofloxacin,
Clindamycin, Erythromycin, Gentamicin, Sulfamethoxazole/Trimethoprim, and
Tetracycline.

## Methodology implemented here

- **Feature set**: reused from a prior SVM-RFE feature-reduction pipeline
  (allele, most_common_allele, ref_locus_tag, eggnog_gene,
  eggnog_annotation), one-hot encoded.
- **Data splitting**: stratified 80/20 train–test split performed at the
  **isolate level** (all rows for one isolate stay in the same partition),
  with the 20% test set held out untouched until final evaluation.
- **Cross-validation**: 5-fold stratified cross-validation within the
  training set, also isolate-level, with `StandardScaler` / one-hot
  encoding fit only on each fold's training rows.
- **Class imbalance**: handled per-model with either
  - **SMOTE** (k=5 nearest neighbours, `random_state=42`), applied only to
    the training portion of each fold, **after** the fold split (never
    touching validation/test rows), or
  - **balanced class weights**, for the models that support them natively
    (Decision Tree, XGBoost, Logistic Regression, SGD).

  SMOTE and class weighting are never combined on the same model.
- **Models and key hyperparameters**:
  - Decision Tree — `max_depth=10`, `min_samples_leaf=1`, `random_state=42`
  - XGBoost — `subsample=0.8`, `colsample_bytree=0.8`, `max_depth=6`, early
    stopping
  - MLP — three hidden layers, dropout + L2 regularisation
  - LSTM / CNN — included as exploratory architectural baselines only,
    since one-hot-encoded allele features do not carry a biologically
    meaningful sequential/spatial order (see manuscript, Section 2.b and
    Section 6)
  - Deep-learning models use early stopping (patience = 10 epochs)
- **Metrics**: Training/Test Accuracy, ROC AUC, F1-score, sensitivity,
  specificity, balanced accuracy, Cohen's κ, and — for MLP, Decision Tree,
  and XGBoost — probabilistic RMSE (pRMSE) as a supplementary,
  probability-calibration-sensitive metric (never a substitute for the
  metrics above).
- **Interpretability**: SHAP (TreeExplainer) for the XGBoost model.

## Repository structure

```
amr_ml_prediction/
├── README.md
├── requirements.txt
├── config.py                  # all hyperparameters / random seeds in one place
├── main.py                    # CLI entry point: run the full pipeline
├── data/                      # place the input feature table here (not tracked)
│   └── README.md
├── src/
│   ├── __init__.py
│   ├── data_preprocessing.py  # loading, isolate-level splitting, leakage-safe fold preprocessing
│   ├── models.py              # builders for all seven models
│   ├── metrics.py             # accuracy/ROC AUC/F1/pRMSE/etc.
│   ├── train.py               # CV + final-fit training loop for all models
│   ├── shap_analysis.py       # SHAP summary plot for XGBoost
│   └── visualize.py           # learning curves, ROC curves, per-drug bar charts
└── outputs/                   # results tables, figures (created at runtime)
```

## Installation

```bash
git clone <this-repo-url>
cd amr_ml_prediction
python -m venv .venv && source .venv/bin/activate   # optional
pip install -r requirements.txt
```

## Data format

Place a single feature table at `data/amr_features.csv` with one row per
(isolate, drug) pair and the following columns:

| column               | description                                              |
|-----------------------|-----------------------------------------------------------|
| `isolate_id`          | unique identifier for the *S. aureus* isolate             |
| `allele`               | allele identifier                                        |
| `most_common_allele`   | most-common-allele call                                  |
| `ref_locus_tag`        | reference locus tag                                      |
| `eggnog_gene`          | EggNOG gene label                                         |
| `eggnog_annotation`    | EggNOG functional annotation                              |
| `drug`                 | antibiotic name (one of the six evaluated)                |
| `label`                | binary AMR label (1 = resistant, 0 = non-resistant)       |

See `data/README.md` for details and for how to point the pipeline at a
differently-named file.

## Usage

Run the full pipeline (preprocessing → CV → final model fits → evaluation →
SHAP → figures):

```bash
python main.py --data data/amr_features.csv --outdir outputs
```

Key options:

```bash
python main.py --help
```

Outputs land in `outputs/`:
- `outputs/table3_model_performance.csv` — the Table 3 results (Training
  Acc., Test Acc., ROC AUC, F1-Score for all seven models)
- `outputs/metrics_extended.csv` — the full metric set per model, including
  pRMSE where applicable
- `outputs/figures/` — learning curves, ROC curves, SHAP summary plot,
  per-drug accuracy/F1 bar charts

## Reproducibility notes

- All random seeds are centralised in `config.py` (`RANDOM_STATE = 42`).
- TensorFlow/Keras training (LSTM, CNN, MLP) is not perfectly
  deterministic run-to-run even with a fixed seed; single-run results
  should be treated as illustrative rather than exact (see manuscript,
  Section 6, Limitations).
- The upstream SVM-RFE feature-selection step is **not** re-run inside this
  pipeline; it was performed once, independently, on the full isolate
  collection prior to this study (see manuscript, Section 2.a).

## Citation

If you use this code, please cite the manuscript:

> Ghosh J, Kant R, Taneja J. Machine Learning–Driven Prediction of
> Antimicrobial Resistance in *Staphylococcus aureus* Using Genomic and
> Allelic Signatures. [journal, year, once published].

## License

MIT — see `LICENSE`.
