"""
Central configuration for the AMR prediction pipeline.

Keeping every hyperparameter and random seed here (rather than scattered
across modules) makes the run fully reproducible and easy to audit against
the manuscript's Methods section.
"""

RANDOM_STATE = 42

# --- Data splitting ---------------------------------------------------
TEST_SIZE = 0.20          # 80/20 train-test split
N_SPLITS = 5               # 5-fold stratified cross-validation
SPLIT_LEVEL = "isolate_id"  # split/fold assignment is done per isolate

# --- Class imbalance handling ------------------------------------------
# Models that use SMOTE (no native class-weighting support)
SMOTE_MODELS = ["LSTM", "CNN", "MLP"]
# Models that use balanced class weights instead of SMOTE
CLASS_WEIGHT_MODELS = ["DecisionTree", "XGBoost", "LogisticRegression", "SGD"]

SMOTE_K_NEIGHBORS = 5

# --- Decision Tree -------------------------------------------------------
DECISION_TREE_PARAMS = dict(
    max_depth=10,
    min_samples_leaf=1,
    class_weight="balanced",
    random_state=RANDOM_STATE,
)

# --- XGBoost ---------------------------------------------------------------
XGBOOST_PARAMS = dict(
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    n_estimators=300,
    learning_rate=0.1,
    eval_metric="logloss",
    random_state=RANDOM_STATE,
)
XGBOOST_EARLY_STOPPING_ROUNDS = 20

# --- Logistic Regression -----------------------------------------------
LOGISTIC_REGRESSION_PARAMS = dict(
    class_weight="balanced",
    max_iter=1000,
    random_state=RANDOM_STATE,
)

# --- SGD -----------------------------------------------------------------
SGD_PARAMS = dict(
    loss="log_loss",
    class_weight="balanced",
    max_iter=1000,
    random_state=RANDOM_STATE,
)

# --- Deep learning (LSTM / CNN / MLP) -------------------------------------
DL_BATCH_SIZE = 32
DL_MAX_EPOCHS = 100
DL_EARLY_STOPPING_PATIENCE = 10
DL_VALIDATION_SPLIT = 0.2

MLP_HIDDEN_UNITS = [128, 64, 32]
MLP_DROPOUT = 0.3
MLP_L2 = 1e-4

LSTM_UNITS = 64
CNN_FILTERS = 64
CNN_KERNEL_SIZE = 3

# --- Metrics -----------------------------------------------------------
PRMSE_MODELS = ["MLP", "DecisionTree", "XGBoost"]

# --- Output -----------------------------------------------------------
FIGURES_DIRNAME = "figures"
TABLE3_FILENAME = "table3_model_performance.csv"
EXTENDED_METRICS_FILENAME = "metrics_extended.csv"
