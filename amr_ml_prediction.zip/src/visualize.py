"""
Plotting helpers for the figures reported in the manuscript (learning
curves, ROC curves, per-drug accuracy/F1 bar charts).
"""

from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve, auc


def plot_learning_curve(history, model_name: str, outpath: str):
    """Plot training/validation accuracy across epochs for a Keras model."""
    if history is None:
        return
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(history.history["accuracy"], label="accuracy")
    ax.plot(history.history["val_accuracy"], label="val_accuracy")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Accuracy")
    ax.set_title(f"Learning curve — {model_name}")
    ax.legend()
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def plot_roc_curve(y_true, y_prob, model_name: str, outpath: str):
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    roc_auc = auc(fpr, tpr)
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.plot(fpr, tpr, label=f"{model_name} ROC curve (area = {roc_auc:.2f})")
    ax.plot([0, 1], [0, 1], linestyle="--", color="navy")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title(f"Receiver Operating Characteristic — {model_name}")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def plot_per_drug_bar(per_drug_df: pd.DataFrame, model_name: str, outpath: str):
    """
    per_drug_df: DataFrame with columns ['drug', 'accuracy', 'f1_score'].
    """
    fig, ax = plt.subplots(figsize=(8, 4))
    x = np.arange(len(per_drug_df))
    width = 0.35
    ax.bar(x - width / 2, per_drug_df["accuracy"], width, label="Accuracy")
    ax.bar(x + width / 2, per_drug_df["f1_score"], width, label="F1-Score")
    ax.set_xticks(x)
    ax.set_xticklabels(per_drug_df["drug"], rotation=45, ha="right")
    ax.set_ylabel("Score")
    ax.set_title(f"Accuracy and F1-Score per drug — {model_name}")
    ax.legend()
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)
