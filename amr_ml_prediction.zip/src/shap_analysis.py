"""
SHAP interpretability analysis for the XGBoost model (manuscript,
Section 3 SHAP discussion / Table 2 / Figure 3).

SHAP importance reflects each feature's statistical contribution to the
model's predictions on this dataset. It is not, by itself, evidence of a
validated biological or functional role (see manuscript, Section 4 and
Section 6).
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def compute_shap_values(xgb_model, X, feature_names):
    import shap

    explainer = shap.TreeExplainer(xgb_model)
    shap_values = explainer.shap_values(X)
    return shap_values, explainer


def top_features_table(shap_values, feature_names, top_n: int = 10) -> pd.DataFrame:
    """
    Build a table of the top-N most important features by mean absolute
    SHAP value, matching the manuscript's feature-importance table.
    """
    mean_abs_shap = np.abs(shap_values).mean(axis=0)
    order = np.argsort(mean_abs_shap)[::-1][:top_n]
    return pd.DataFrame(
        {
            "Feature #": np.arange(1, len(order) + 1),
            "Feature Name": [feature_names[i] for i in order],
            "Importance": mean_abs_shap[order],
        }
    )


def plot_shap_summary(shap_values, X, feature_names, outpath: str):
    import matplotlib.pyplot as plt
    import shap

    shap.summary_plot(shap_values, X, feature_names=feature_names, show=False)
    plt.tight_layout()
    plt.savefig(outpath, dpi=150, bbox_inches="tight")
    plt.close()
