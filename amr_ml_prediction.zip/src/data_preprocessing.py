"""
Data loading and leakage-safe preprocessing.

Design goals (matching the manuscript's Methods, Section 2.a / 2.f):

1. The 80/20 train-test split is performed once, at the *isolate* level,
   before anything else touches the test set.
2. Within the training partition, 5-fold stratified cross-validation is
   also performed at the isolate level.
3. For every fold, `StandardScaler` and one-hot encoding are fit ONLY on
   that fold's training rows, then applied to its validation rows -- never
   the reverse. This is enforced by always calling `fit_fold_preprocessor`
   on the training rows of a fold and re-using the returned transformer for
   the corresponding validation/test rows.
4. SMOTE (where used) is applied only to the training portion of a fold,
   after the fold split, so synthetic minority-class rows never leak into
   a validation or test partition.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold, train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer

import config

CATEGORICAL_COLS = [
    "allele",
    "most_common_allele",
    "ref_locus_tag",
    "eggnog_gene",
    "eggnog_annotation",
]
GROUP_COL = "isolate_id"
LABEL_COL = "label"


def load_data(path: str) -> pd.DataFrame:
    """Load the raw feature table described in data/README.md."""
    df = pd.read_csv(path)
    missing = set(CATEGORICAL_COLS + [GROUP_COL, LABEL_COL, "drug"]) - set(df.columns)
    if missing:
        raise ValueError(f"Input data is missing required columns: {sorted(missing)}")
    return df


def isolate_level_train_test_split(df: pd.DataFrame):
    """
    Stratified 80/20 split performed at the isolate level: every row for a
    given isolate stays in the same partition.
    """
    isolates = df[[GROUP_COL, LABEL_COL]].drop_duplicates(subset=GROUP_COL)
    train_ids, test_ids = train_test_split(
        isolates[GROUP_COL],
        test_size=config.TEST_SIZE,
        stratify=isolates[LABEL_COL],
        random_state=config.RANDOM_STATE,
    )
    train_df = df[df[GROUP_COL].isin(train_ids)].reset_index(drop=True)
    test_df = df[df[GROUP_COL].isin(test_ids)].reset_index(drop=True)
    return train_df, test_df


def isolate_level_cv_folds(train_df: pd.DataFrame):
    """
    Yield (fold_train_idx, fold_val_idx) index arrays for 5-fold stratified
    cross-validation performed at the isolate level, so no isolate appears
    in both the training and validation portion of the same fold.
    """
    splitter = StratifiedGroupKFold(
        n_splits=config.N_SPLITS, shuffle=True, random_state=config.RANDOM_STATE
    )
    X = train_df.index.values
    y = train_df[LABEL_COL].values
    groups = train_df[GROUP_COL].values
    for fold_train_idx, fold_val_idx in splitter.split(X, y, groups):
        yield fold_train_idx, fold_val_idx


@dataclass
class FoldPreprocessor:
    """
    Fitted-on-training-rows-only transformer bundle for one fold (or for
    the final train/test split). Holds the one-hot encoder for categorical
    columns and the StandardScaler for any numeric columns.
    """

    encoder: OneHotEncoder
    scaler: StandardScaler | None
    numeric_cols: list

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        cat = self.encoder.transform(df[CATEGORICAL_COLS])
        if self.numeric_cols:
            num = self.scaler.transform(df[self.numeric_cols])
            return np.hstack([cat, num])
        return cat


def fit_fold_preprocessor(train_rows: pd.DataFrame, numeric_cols=None) -> FoldPreprocessor:
    """
    Fit the one-hot encoder (and optional scaler) on this fold's TRAINING
    rows only. The returned object should then be used to `.transform()`
    both the training rows and the corresponding validation/test rows.
    """
    numeric_cols = numeric_cols or []
    encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    encoder.fit(train_rows[CATEGORICAL_COLS])

    scaler = None
    if numeric_cols:
        scaler = StandardScaler()
        scaler.fit(train_rows[numeric_cols])

    return FoldPreprocessor(encoder=encoder, scaler=scaler, numeric_cols=numeric_cols)


def apply_smote(X: np.ndarray, y: np.ndarray):
    """
    Apply SMOTE to a TRAINING partition only. Never call this on
    validation or test data.
    """
    from imblearn.over_sampling import SMOTE

    smote = SMOTE(k_neighbors=config.SMOTE_K_NEIGHBORS, random_state=config.RANDOM_STATE)
    return smote.fit_resample(X, y)
