"""
End-to-end training pipeline for all seven models.

For each model:
1. Run 5-fold stratified, isolate-level cross-validation on the training
   partition ONLY, to obtain a robust internal performance estimate
   (fold-wise leakage-safe preprocessing + fold-wise SMOTE/class weights).
2. Refit the model on the FULL training partition (with the same
   leakage-safe preprocessing / imbalance handling) and evaluate once on
   the held-out test partition -- this final test-set evaluation is what
   is reported in Table 3.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

import config
from src import models
from src.data_preprocessing import (
    LABEL_COL,
    apply_smote,
    fit_fold_preprocessor,
    isolate_level_cv_folds,
)
from src.metrics import compute_all_metrics


def _uses_smote(model_name: str) -> bool:
    return model_name in config.SMOTE_MODELS


def _is_deep_learning(model_name: str) -> bool:
    return model_name in models.DEEP_LEARNING_BUILDERS


def _fit_predict_classical(model_name, X_train, y_train, X_val):
    builder = models.CLASSICAL_BUILDERS[model_name]
    clf = builder()
    if model_name == "XGBoost":
        clf.fit(X_train, y_train)
    else:
        clf.fit(X_train, y_train)
    y_prob = clf.predict_proba(X_val)[:, 1]
    y_pred = (y_prob >= 0.5).astype(int)
    return clf, y_pred, y_prob


def _fit_predict_deep(model_name, X_train, y_train, X_val):
    builder = models.DEEP_LEARNING_BUILDERS[model_name]
    from tensorflow import keras

    input_dim = X_train.shape[1]
    if model_name in ("LSTM", "CNN"):
        X_train_in = X_train.reshape(X_train.shape[0], X_train.shape[1], 1)
        X_val_in = X_val.reshape(X_val.shape[0], X_val.shape[1], 1)
    else:
        X_train_in, X_val_in = X_train, X_val

    model = builder(input_dim)
    early_stop = keras.callbacks.EarlyStopping(
        monitor="val_loss",
        patience=config.DL_EARLY_STOPPING_PATIENCE,
        restore_best_weights=True,
    )
    history = model.fit(
        X_train_in,
        y_train,
        validation_split=config.DL_VALIDATION_SPLIT,
        epochs=config.DL_MAX_EPOCHS,
        batch_size=config.DL_BATCH_SIZE,
        callbacks=[early_stop],
        verbose=0,
    )
    y_prob = model.predict(X_val_in, verbose=0).ravel()
    y_pred = (y_prob >= 0.5).astype(int)
    return model, y_pred, y_prob, history


def _prepare_fold_arrays(train_df, val_df, numeric_cols=None):
    """Fit preprocessing on the fold's training rows only, transform both."""
    pre = fit_fold_preprocessor(train_df, numeric_cols=numeric_cols)
    X_train = pre.transform(train_df)
    X_val = pre.transform(val_df)
    y_train = train_df[LABEL_COL].values
    y_val = val_df[LABEL_COL].values
    return pre, X_train, y_train, X_val, y_val


def cross_validate_model(model_name: str, train_df):
    """
    5-fold stratified, isolate-level CV for one model. Returns a list of
    per-fold metric dicts (test-set-style metrics computed on each fold's
    validation split).
    """
    fold_metrics = []
    for fold_train_idx, fold_val_idx in isolate_level_cv_folds(train_df):
        fold_train_df = train_df.iloc[fold_train_idx]
        fold_val_df = train_df.iloc[fold_val_idx]

        _, X_train, y_train, X_val, y_val = _prepare_fold_arrays(
            fold_train_df, fold_val_df
        )

        if _uses_smote(model_name):
            X_train, y_train = apply_smote(X_train, y_train)
        # else: class_weight="balanced" is baked into the classical model
        # builders for CLASS_WEIGHT_MODELS.

        if _is_deep_learning(model_name):
            _, y_pred, y_prob, _ = _fit_predict_deep(model_name, X_train, y_train, X_val)
        else:
            _, y_pred, y_prob = _fit_predict_classical(model_name, X_train, y_train, X_val)

        include_prmse = model_name in config.PRMSE_MODELS
        fold_metrics.append(compute_all_metrics(y_val, y_pred, y_prob, include_prmse))

    return fold_metrics


def final_fit_and_test(model_name: str, train_df, test_df):
    """
    Refit on the full training partition (leakage-safe preprocessing,
    fold-analogous imbalance handling) and evaluate once on the held-out
    test partition. This is what populates Table 3.
    """
    pre, X_train, y_train, X_test, y_test = _prepare_fold_arrays(train_df, test_df)

    if _uses_smote(model_name):
        X_train, y_train = apply_smote(X_train, y_train)

    include_prmse = model_name in config.PRMSE_MODELS

    if _is_deep_learning(model_name):
        fitted, y_pred, y_prob, history = _fit_predict_deep(
            model_name, X_train, y_train, X_test
        )
        train_prob = fitted.predict(
            X_train.reshape(X_train.shape[0], X_train.shape[1], 1)
            if model_name in ("LSTM", "CNN")
            else X_train,
            verbose=0,
        ).ravel()
    else:
        fitted, y_pred, y_prob = _fit_predict_classical(model_name, X_train, y_train, X_test)
        train_prob = fitted.predict_proba(X_train)[:, 1]
        history = None

    train_pred = (train_prob >= 0.5).astype(int)
    train_metrics = compute_all_metrics(y_train, train_pred, train_prob, include_prmse)
    test_metrics = compute_all_metrics(y_test, y_pred, y_prob, include_prmse)

    return {
        "model": fitted,
        "history": history,
        "train_metrics": train_metrics,
        "test_metrics": test_metrics,
        "y_test": y_test,
        "y_pred": y_pred,
        "y_prob": y_prob,
    }


def run_all_models(train_df, test_df):
    """
    Run CV + final fit/test for all seven models. Returns:
    - results: dict[model_name] -> final_fit_and_test() output
    - table3: pd.DataFrame matching the manuscript's Table 3
    """
    results = {}
    table3_rows = []

    for model_name in models.ALL_MODEL_NAMES:
        print(f"[{model_name}] running cross-validation...")
        cv_metrics = cross_validate_model(model_name, train_df)
        cv_df = pd.DataFrame(cv_metrics)
        print(f"[{model_name}] CV mean ROC AUC: {cv_df['roc_auc'].mean():.4f}")

        print(f"[{model_name}] final fit + test evaluation...")
        result = final_fit_and_test(model_name, train_df, test_df)
        result["cv_metrics"] = cv_df
        results[model_name] = result

        table3_rows.append(
            {
                "Model": model_name,
                "Training Acc. (%)": round(100 * result["train_metrics"]["accuracy"], 2),
                "Test Acc. (%)": round(100 * result["test_metrics"]["accuracy"], 2),
                "ROC AUC": round(result["test_metrics"]["roc_auc"], 4),
                "F1-Score": round(result["test_metrics"]["f1_score"], 4),
            }
        )

    table3 = pd.DataFrame(table3_rows)
    return results, table3
