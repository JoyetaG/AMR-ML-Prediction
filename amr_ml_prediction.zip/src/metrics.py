"""
Evaluation metrics used throughout the manuscript's Results (Section 2.c,
Section 3, Table 3).
"""

from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    cohen_kappa_score,
    f1_score,
    roc_auc_score,
)


def probabilistic_rmse(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """
    pRMSE: root-mean-squared error between the predicted class probability
    and the binary ground-truth label.

    This is reported only as a supplementary, probability-calibration-
    sensitive statistic (for MLP, Decision Tree, and XGBoost) -- it is
    not a substitute for accuracy, F1-score, or ROC AUC (manuscript,
    Section 2.c).
    """
    y_true = np.asarray(y_true, dtype=float)
    y_prob = np.asarray(y_prob, dtype=float)
    return float(np.sqrt(np.mean((y_prob - y_true) ** 2)))


def sensitivity_specificity(y_true: np.ndarray, y_pred: np.ndarray):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    tp = np.sum((y_true == 1) & (y_pred == 1))
    fn = np.sum((y_true == 1) & (y_pred == 0))
    tn = np.sum((y_true == 0) & (y_pred == 0))
    fp = np.sum((y_true == 0) & (y_pred == 1))
    sensitivity = tp / (tp + fn) if (tp + fn) else float("nan")
    specificity = tn / (tn + fp) if (tn + fp) else float("nan")
    return sensitivity, specificity


def compute_all_metrics(
    y_true, y_pred, y_prob, include_prmse: bool = False
) -> dict:
    """
    Compute the full metric set for one train- or test-set prediction.
    `y_prob` should be the predicted probability of the positive
    (resistant) class.
    """
    sens, spec = sensitivity_specificity(y_true, y_pred)
    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "roc_auc": roc_auc_score(y_true, y_prob),
        "f1_score": f1_score(y_true, y_pred),
        "sensitivity": sens,
        "specificity": spec,
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "cohens_kappa": cohen_kappa_score(y_true, y_pred),
    }
    if include_prmse:
        metrics["prmse"] = probabilistic_rmse(y_true, y_prob)
    return metrics
