"""
Builders for the seven models compared in the manuscript:
LSTM, CNN, MLP, Decision Tree, XGBoost, Logistic Regression, SGD.
"""

from __future__ import annotations

from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression, SGDClassifier
from xgboost import XGBClassifier

import config


# --------------------------------------------------------------------------
# Classical / ensemble models (scikit-learn, XGBoost)
# --------------------------------------------------------------------------
def build_decision_tree() -> DecisionTreeClassifier:
    return DecisionTreeClassifier(**config.DECISION_TREE_PARAMS)


def build_xgboost() -> XGBClassifier:
    return XGBClassifier(**config.XGBOOST_PARAMS)


def build_logistic_regression() -> LogisticRegression:
    return LogisticRegression(**config.LOGISTIC_REGRESSION_PARAMS)


def build_sgd() -> SGDClassifier:
    return SGDClassifier(**config.SGD_PARAMS)


# --------------------------------------------------------------------------
# Deep learning models (TensorFlow/Keras)
#
# LSTM and CNN are included as exploratory architectural baselines only:
# the one-hot-encoded allele/EggNOG feature vectors do not carry a
# biologically meaningful sequential or spatial order (manuscript,
# Section 2.b / Section 6). Their comparatively strong performance should
# be read as general model capacity/expressiveness on this feature set,
# not as evidence of genuine sequence-structure exploitation.
# --------------------------------------------------------------------------
def build_mlp(input_dim: int):
    from tensorflow import keras
    from tensorflow.keras import layers, regularizers

    model = keras.Sequential(name="MLP")
    model.add(layers.Input(shape=(input_dim,)))
    for units in config.MLP_HIDDEN_UNITS:
        model.add(
            layers.Dense(
                units,
                activation="relu",
                kernel_regularizer=regularizers.l2(config.MLP_L2),
            )
        )
        model.add(layers.Dropout(config.MLP_DROPOUT))
    model.add(layers.Dense(1, activation="sigmoid"))
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    return model


def build_lstm(input_dim: int):
    """
    Input is reshaped to (n_samples, input_dim, 1) -- i.e. each one-hot
    feature is treated as one timestep. See the caveat in the module
    docstring: this is an architectural baseline, not a claim of genuine
    sequential structure in the data.
    """
    from tensorflow import keras
    from tensorflow.keras import layers

    model = keras.Sequential(name="LSTM")
    model.add(layers.Input(shape=(input_dim, 1)))
    model.add(layers.LSTM(config.LSTM_UNITS))
    model.add(layers.Dense(1, activation="sigmoid"))
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    return model


def build_cnn(input_dim: int):
    from tensorflow import keras
    from tensorflow.keras import layers

    model = keras.Sequential(name="CNN")
    model.add(layers.Input(shape=(input_dim, 1)))
    model.add(
        layers.Conv1D(
            config.CNN_FILTERS, config.CNN_KERNEL_SIZE, activation="relu", padding="same"
        )
    )
    model.add(layers.GlobalMaxPooling1D())
    model.add(layers.Dense(32, activation="relu"))
    model.add(layers.Dense(1, activation="sigmoid"))
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    return model


DEEP_LEARNING_BUILDERS = {
    "LSTM": build_lstm,
    "CNN": build_cnn,
    "MLP": build_mlp,
}

CLASSICAL_BUILDERS = {
    "DecisionTree": build_decision_tree,
    "XGBoost": build_xgboost,
    "LogisticRegression": build_logistic_regression,
    "SGD": build_sgd,
}

ALL_MODEL_NAMES = list(DEEP_LEARNING_BUILDERS) + list(CLASSICAL_BUILDERS)
