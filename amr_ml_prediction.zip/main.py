"""
CLI entry point for the AMR prediction pipeline.

Usage:
    python main.py --data data/amr_features.csv --outdir outputs
"""

from __future__ import annotations

import argparse
import os

import numpy as np
import pandas as pd

import config
from src.data_preprocessing import isolate_level_train_test_split, load_data
from src.train import run_all_models
from src import shap_analysis, visualize


def parse_args():
    parser = argparse.ArgumentParser(description="AMR prediction pipeline")
    parser.add_argument(
        "--data", default="data/amr_features.csv", help="Path to the input feature table."
    )
    parser.add_argument(
        "--outdir", default="outputs", help="Directory to write results and figures to."
    )
    parser.add_argument(
        "--skip-shap",
        action="store_true",
        help="Skip the SHAP analysis for XGBoost (faster smoke-test runs).",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    np.random.seed(config.RANDOM_STATE)

    os.makedirs(args.outdir, exist_ok=True)
    fig_dir = os.path.join(args.outdir, config.FIGURES_DIRNAME)
    os.makedirs(fig_dir, exist_ok=True)

    print(f"Loading data from {args.data} ...")
    df = load_data(args.data)

    print("Splitting isolates into 80% train / 20% test (stratified, isolate-level) ...")
    train_df, test_df = isolate_level_train_test_split(df)
    print(f"  train: {train_df['isolate_id'].nunique()} isolates, {len(train_df)} rows")
    print(f"  test:  {test_df['isolate_id'].nunique()} isolates, {len(test_df)} rows")

    results, table3 = run_all_models(train_df, test_df)

    table3_path = os.path.join(args.outdir, config.TABLE3_FILENAME)
    table3.to_csv(table3_path, index=False)
    print(f"\nTable 3 (model performance) written to {table3_path}")
    print(table3.to_string(index=False))

    # Extended per-model metrics (including pRMSE where applicable)
    extended_rows = []
    for model_name, result in results.items():
        row = {"model": model_name, "split": "test", **result["test_metrics"]}
        extended_rows.append(row)
        row = {"model": model_name, "split": "train", **result["train_metrics"]}
        extended_rows.append(row)
    extended_df = pd.DataFrame(extended_rows)
    extended_path = os.path.join(args.outdir, config.EXTENDED_METRICS_FILENAME)
    extended_df.to_csv(extended_path, index=False)
    print(f"Extended metrics written to {extended_path}")

    # Figures: learning curves + ROC curves for every model
    for model_name, result in results.items():
        if result.get("history") is not None:
            visualize.plot_learning_curve(
                result["history"],
                model_name,
                os.path.join(fig_dir, f"learning_curve_{model_name}.png"),
            )
        visualize.plot_roc_curve(
            result["y_test"],
            result["y_prob"],
            model_name,
            os.path.join(fig_dir, f"roc_curve_{model_name}.png"),
        )

    # SHAP analysis for XGBoost
    if not args.skip_shap:
        print("\nRunning SHAP analysis for XGBoost ...")
        xgb_result = results["XGBoost"]
        # Re-derive the transformed test matrix + feature names for SHAP.
        from src.data_preprocessing import fit_fold_preprocessor

        pre = fit_fold_preprocessor(train_df)
        X_test = pre.transform(test_df)
        feature_names = list(pre.encoder.get_feature_names_out())

        shap_values, _ = shap_analysis.compute_shap_values(
            xgb_result["model"], X_test, feature_names
        )
        top_features = shap_analysis.top_features_table(shap_values, feature_names, top_n=10)
        top_features_path = os.path.join(args.outdir, "table2_top_shap_features.csv")
        top_features.to_csv(top_features_path, index=False)
        print(f"Top SHAP features (Table 2) written to {top_features_path}")

        shap_analysis.plot_shap_summary(
            shap_values, X_test, feature_names, os.path.join(fig_dir, "shap_summary_xgboost.png")
        )

    print("\nDone.")


if __name__ == "__main__":
    main()
